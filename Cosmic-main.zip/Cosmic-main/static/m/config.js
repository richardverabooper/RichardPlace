self.__uv$config = {
    prefix: '/a/',
    bare: '/o/',
    encodeUrl:  Ultraviolet.codec.xor.encode,
    decodeUrl: Ultraviolet.codec.xor.decode,
    handler: '/m/handler.js?v=4',
    bundle: '/m/bundle.js?v=4',
    config: '/m/config.js?v=4',
    sw: '/m/sw.js?v=4',
};